This directory contains the auto-generated protocol files for the Wayland
System Integration.

To re-generate them run make.

It requires wayland-scanner to be installed, which is generally found as
wayland-utils package in Linux distributions.

Included as of Vim patch v9.1.1485 (2025 Jun 27).

Initial work done by Foxe Chen.
