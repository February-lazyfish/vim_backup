#!/bin/dash

echo ${foo:-'string \'}

